import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/layout/header";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-dnx-gradient overflow-hidden min-h-[90vh] flex items-center">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-20 left-20 w-96 h-96 bg-white rounded-full mix-blend-multiply filter blur-3xl animate-float"></div>
          <div className="absolute top-40 right-20 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-2xl animate-float" style={{animationDelay: '2s'}}></div>
          <div className="absolute -bottom-8 left-1/2 w-72 h-72 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl animate-float" style={{animationDelay: '4s'}}></div>
          <div className="absolute top-1/2 left-10 w-64 h-64 bg-blue-300 rounded-full mix-blend-multiply filter blur-2xl animate-float" style={{animationDelay: '1s'}}></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left animate-slide-up">
              <div className="inline-flex items-center px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-white text-sm font-medium mb-6">
                <span className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></span>
                Plataforma em funcionamento
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold text-white leading-tight">
                Automatize seu
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-200 to-white animate-glow">Negócio com IA</span>
              </h1>
              <p className="mt-8 text-xl text-purple-100 max-w-2xl leading-relaxed">
                Plataforma completa de automação empresarial com inteligência artificial. 
                Workflows, CRM, chatbots e muito mais em uma solução integrada e moderna.
              </p>
              <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button asChild size="lg" className="bg-white hover:bg-gray-100 text-dnx-primary shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-105">
                  <Link href="/login">
                    <i className="fas fa-rocket mr-2"></i>
                    Começar Agora
                  </Link>
                </Button>
                <Button variant="outline" size="lg" className="border-2 border-white/50 text-white hover:bg-white/10 hover:border-white backdrop-blur-sm transition-all duration-300">
                  <i className="fas fa-play mr-2"></i>
                  Ver Demo
                </Button>
              </div>
              <div className="mt-8 flex items-center justify-center lg:justify-start space-x-6 text-purple-200">
                <div className="flex items-center">
                  <i className="fas fa-check-circle mr-2"></i>
                  <span className="text-sm">Setup em 5 minutos</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-shield-alt mr-2"></i>
                  <span className="text-sm">100% Seguro</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-headset mr-2"></i>
                  <span className="text-sm">Suporte 24/7</span>
                </div>
              </div>
            </div>
            
            {/* Enhanced Dashboard Preview */}
            <div className="relative animate-float">
              <div className="absolute inset-0 bg-dnx-gradient opacity-20 rounded-2xl blur-xl"></div>
              <Card className="transform rotate-2 hover:rotate-0 transition-all duration-500 shadow-2xl hover:shadow-3xl relative backdrop-blur-sm border-white/20">
                <CardContent className="p-8">
                  <div className="bg-gradient-to-br from-white to-gray-50 rounded-xl p-6 shadow-inner">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="font-bold text-gray-900 text-lg">Dashboard Analytics</h3>
                      <div className="flex space-x-2">
                        <div className="w-3 h-3 bg-red-400 rounded-full animate-pulse"></div>
                        <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse" style={{animationDelay: '0.5s'}}></div>
                        <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse" style={{animationDelay: '1s'}}></div>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4 mb-6">
                      <div className="bg-gradient-to-br from-white to-purple-50 p-4 rounded-xl text-center shadow-md hover:shadow-lg transition-shadow">
                        <div className="text-2xl font-bold text-dnx-primary animate-pulse">R$ 45.2K</div>
                        <div className="text-xs text-gray-600 font-medium">Receita</div>
                      </div>
                      <div className="bg-gradient-to-br from-white to-green-50 p-4 rounded-xl text-center shadow-md hover:shadow-lg transition-shadow">
                        <div className="text-2xl font-bold text-green-600 animate-pulse">127</div>
                        <div className="text-xs text-gray-600 font-medium">Conversões</div>
                      </div>
                      <div className="bg-gradient-to-br from-white to-blue-50 p-4 rounded-xl text-center shadow-md hover:shadow-lg transition-shadow">
                        <div className="text-2xl font-bold text-blue-600 animate-pulse">1.2K</div>
                        <div className="text-xs text-gray-600 font-medium">Leads</div>
                      </div>
                    </div>
                    <div className="bg-dnx-gradient h-24 rounded-xl flex items-end justify-between p-4 relative overflow-hidden">
                      <div className="absolute inset-0 bg-white/10 backdrop-blur-sm"></div>
                      <div className="bg-white/40 w-6 h-10 rounded-t-lg relative animate-pulse"></div>
                      <div className="bg-white/60 w-6 h-16 rounded-t-lg relative animate-pulse" style={{animationDelay: '0.2s'}}></div>
                      <div className="bg-white/80 w-6 h-20 rounded-t-lg relative animate-pulse" style={{animationDelay: '0.4s'}}></div>
                      <div className="bg-white/70 w-6 h-12 rounded-t-lg relative animate-pulse" style={{animationDelay: '0.6s'}}></div>
                      <div className="bg-white w-6 h-18 rounded-t-lg relative animate-pulse" style={{animationDelay: '0.8s'}}></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Recursos Completos</h2>
            <p className="text-xl text-gray-600">Tudo que sua empresa precisa em uma única plataforma</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 bg-gradient-to-br from-white to-purple-50 border-purple-100">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-dnx-gradient rounded-xl flex items-center justify-center mb-6 shadow-lg animate-glow">
                  <i className="fas fa-project-diagram text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Workflows Inteligentes</h3>
                <p className="text-gray-600 mb-6">Automatize processos complexos com workflows visuais e inteligência artificial integrada.</p>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Editor visual drag-and-drop</li>
                  <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Integração com APIs externas</li>
                  <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Triggers automáticos</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 bg-gradient-to-br from-white to-blue-50 border-blue-100">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mb-6 shadow-lg animate-glow">
                  <i className="fas fa-users text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">CRM Avançado</h3>
                <p className="text-gray-600 mb-6">Gerencie leads, clientes e oportunidades com ferramentas de análise preditiva.</p>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Pipeline de vendas visual</li>
                  <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Scoring automático de leads</li>
                  <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Relatórios em tempo real</li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 bg-gradient-to-br from-white to-green-50 border-green-100">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center mb-6 shadow-lg animate-glow">
                  <i className="fas fa-robot text-white text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Chatbot IA</h3>
                <p className="text-gray-600 mb-6">Atendimento automatizado 24/7 com inteligência artificial contextual.</p>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Processamento de linguagem natural</li>
                  <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Integração com WhatsApp</li>
                  <li className="flex items-center"><i className="fas fa-check text-green-500 mr-2"></i>Aprendizado contínuo</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-dnx-primary to-dnx-secondary rounded-lg flex items-center justify-center mr-4">
                  <span className="text-white font-bold text-lg">DN</span>
                </div>
                <span className="text-2xl font-bold">DNXTAI</span>
              </div>
              <p className="text-gray-400 mb-6 max-w-md">
                Transforme seu negócio com automação inteligente. 
                Plataforma completa para empresas que querem crescer com tecnologia.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 bg-gray-800 hover:bg-dnx-primary rounded-lg flex items-center justify-center transition-colors">
                  <i className="fab fa-linkedin"></i>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 hover:bg-dnx-primary rounded-lg flex items-center justify-center transition-colors">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 hover:bg-dnx-primary rounded-lg flex items-center justify-center transition-colors">
                  <i className="fab fa-instagram"></i>
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-6">Produto</h4>
              <ul className="space-y-3 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Recursos</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Preços</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Integrações</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-6">Suporte</h4>
              <ul className="space-y-3 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Documentação</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Tutoriais</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contato</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Status</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">© 2024 DNXTAI. Todos os direitos reservados.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Privacidade</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Termos</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Cookies</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
