/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        purple: {
          700: '#5B21B6',
          900: '#3B0764'
        }
      }
    }
  },
  plugins: [],
}
