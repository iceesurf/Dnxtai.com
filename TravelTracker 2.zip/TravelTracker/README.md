# DNXTAI - Plataforma de Automação Empresarial

Uma plataforma completa de automação e CRM com inteligência artificial para empresas.

## 🚀 Funcionalidades

- **Sistema de Autenticação JWT** - Login seguro com diferentes níveis de acesso
- **Dashboard Empresarial** - Métricas e indicadores em tempo real
- **Painel Administrativo** - Gerenciamento de empresas e usuários
- **Interface Responsiva** - Design moderno com identidade visual DNXTAI
- **Multi-Tenant** - Isolamento de dados por empresa
- **API REST** - Backend robusto e escalável

## 🛠️ Tecnologias

- **Frontend**: React 18, TypeScript, Tailwind CSS, Shadcn/ui
- **Backend**: Node.js, Express, JWT, bcrypt
- **Banco**: PostgreSQL com Drizzle ORM
- **Build**: Vite, esbuild

## 📦 Instalação Local

```bash
# Clone o repositório
git clone <seu-repo>
cd dnxtai-platform

# Instale as dependências
npm install

# Execute em desenvolvimento
npm run dev

# Build para produção
npm run build

# Execute em produção
npm start
```

## 🌐 Deploy

### Vercel
```bash
vercel --prod
```

### Railway
```bash
railway login
railway link
railway up
```

### Docker
```bash
docker build -t dnxtai .
docker run -p 5000:5000 dnxtai
```

### Netlify
- Conecte seu repositório
- Build command: `npm run build`
- Publish directory: `client/dist`

## 🔑 Contas de Demonstração

- **Admin**: admin@dnxtai.com / senha123
- **Empresa**: user@empresa.com / senha123

## 📁 Estrutura do Projeto

```
dnxtai-platform/
├── client/               # Frontend React
│   ├── src/
│   │   ├── components/   # Componentes UI
│   │   ├── pages/        # Páginas da aplicação
│   │   ├── hooks/        # Hooks customizados
│   │   └── lib/          # Utilities e configurações
├── server/               # Backend Node.js
│   ├── index.ts          # Servidor principal
│   ├── routes.ts         # Rotas da API
│   └── storage.ts        # Camada de dados
├── shared/               # Código compartilhado
│   └── schema.ts         # Schemas e tipos
└── dist/                 # Build de produção
```

## 🔧 Configuração

### Variáveis de Ambiente

```env
NODE_ENV=production
PORT=5000
JWT_SECRET=seu_jwt_secret_aqui
DATABASE_URL=sua_conexao_postgresql
```

### Scripts Disponíveis

- `npm run dev` - Executa em desenvolvimento
- `npm run build` - Build completo (client + server)
- `npm run build:client` - Build apenas do frontend
- `npm run build:server` - Build apenas do backend
- `npm start` - Executa em produção
- `npm run typecheck` - Verificação de tipos

## 📊 API Endpoints

### Autenticação
- `POST /api/login` - Login de usuário

### Dashboard
- `GET /api/dashboard/stats` - Estatísticas do dashboard
- `GET /api/dashboard/activities` - Atividades recentes

### Admin (requer permissão admin)
- `GET /api/companies` - Listar empresas
- `POST /api/companies/:id/status` - Alterar status da empresa

## 🎨 Design System

A aplicação utiliza a identidade visual DNXTAI com:
- **Cor Primária**: `hsl(270, 71%, 56%)` (Roxo)
- **Cor Secundária**: `hsl(261, 83%, 58%)`
- **Tipografia**: Inter (sistema)
- **Componentes**: Shadcn/ui + Radix UI

## 📱 Responsividade

- **Mobile First**: Layout otimizado para dispositivos móveis
- **Breakpoints**: sm (640px), md (768px), lg (1024px), xl (1280px)
- **Componentes Adaptativos**: Sidebar, cards, tabelas

## 🔐 Segurança

- **JWT Tokens**: Autenticação stateless
- **bcrypt**: Hash de senhas
- **CORS**: Configurado para produção
- **Validação**: Zod schemas em todas as entradas
- **Rate Limiting**: Proteção contra ataques

## 📈 Performance

- **Code Splitting**: Carregamento otimizado
- **Tree Shaking**: Bundle otimizado
- **SSG Ready**: Preparado para geração estática
- **CDN Ready**: Assets otimizados para CDN

## 🧪 Testes

```bash
# Executar testes (quando implementados)
npm test

# Coverage
npm run test:coverage
```

## 📋 TODO / Roadmap

- [ ] Implementar módulo de Workflows
- [ ] Adicionar sistema de Chatbot
- [ ] Integração com APIs externas
- [ ] Sistema de notificações
- [ ] Relatórios avançados
- [ ] Backup automático
- [ ] Logs e monitoramento

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Propriedade da DNXTAI - Todos os direitos reservados.

## 📞 Suporte

- **Email**: suporte@dnxtai.com
- **Website**: https://dnxtai.com
- **Documentação**: https://docs.dnxtai.com

---

**DNXTAI** - Transformando negócios com automação inteligente.