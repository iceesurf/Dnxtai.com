import { apiRequest } from "./queryClient";

export interface User {
  id: number;
  email: string;
  role: string;
  companyId?: number;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export const authApi = {
  async login(email: string, password: string): Promise<AuthResponse> {
    const response = await apiRequest("POST", "/api/login", { email, password });
    return response.json();
  },

  setToken(token: string) {
    localStorage.setItem("authToken", token);
  },

  getToken(): string | null {
    return localStorage.getItem("authToken");
  },

  removeToken() {
    localStorage.removeItem("authToken");
  },

  isAuthenticated(): boolean {
    return !!this.getToken();
  },
};
