import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";

export default function Login() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      await login(email, password);
      setLocation("/dashboard");
    } catch (err: any) {
      setError(err.message || "Erro ao fazer login");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 via-purple-50 to-gray-100 py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-20 left-20 w-96 h-96 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl animate-float"></div>
        <div className="absolute bottom-20 right-20 w-80 h-80 bg-blue-300 rounded-full mix-blend-multiply filter blur-2xl animate-float" style={{animationDelay: '2s'}}></div>
      </div>
      
      <div className="max-w-md w-full space-y-8 relative z-10">
        <div className="text-center animate-slide-up">
          <div className="w-20 h-20 bg-dnx-gradient rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-2xl animate-glow">
            <i className="fas fa-user-shield text-white text-3xl"></i>
          </div>
          <h2 className="text-4xl font-bold bg-gradient-to-r from-gray-900 to-dnx-primary bg-clip-text text-transparent">Entrar na Plataforma</h2>
          <p className="text-gray-600 mt-3 text-lg">Acesse seu dashboard empresarial</p>
        </div>

        <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-lg animate-scale-in">
          <CardHeader>
            <CardTitle className="text-center text-2xl font-bold bg-gradient-to-r from-dnx-primary to-dnx-secondary bg-clip-text text-transparent">DNXTAI Login</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@dnxtai.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="senha123"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="mt-1"
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox id="remember" />
                  <Label htmlFor="remember" className="text-sm text-gray-600">
                    Lembrar-me
                  </Label>
                </div>
                <a href="#" className="text-sm text-dnx-primary hover:text-dnx-dark">
                  Esqueci a senha
                </a>
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button
                type="submit"
                className="w-full bg-dnx-gradient hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                disabled={loading}
              >
                {loading ? (
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                ) : (
                  <i className="fas fa-sign-in-alt mr-2"></i>
                )}
                {loading ? "Entrando..." : "Entrar"}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">
                Não tem conta?{" "}
                <a href="#" className="text-dnx-primary hover:text-dnx-dark font-medium">
                  Solicitar acesso
                </a>
              </p>
            </div>

            <div className="mt-6 p-6 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl border border-purple-100">
              <h4 className="font-bold text-gray-900 mb-3 flex items-center">
                <i className="fas fa-info-circle text-dnx-primary mr-2"></i>
                Contas de Demonstração
              </h4>
              <div className="text-sm text-gray-700 space-y-2">
                <div className="flex items-center p-2 bg-white/60 rounded-lg">
                  <i className="fas fa-crown text-yellow-500 mr-2"></i>
                  <span><strong>Admin:</strong> admin@dnxtai.com / senha123</span>
                </div>
                <div className="flex items-center p-2 bg-white/60 rounded-lg">
                  <i className="fas fa-building text-blue-500 mr-2"></i>
                  <span><strong>Empresa:</strong> user@empresa.com / senha123</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
