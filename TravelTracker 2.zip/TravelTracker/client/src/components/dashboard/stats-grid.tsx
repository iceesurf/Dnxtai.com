import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface StatsGridProps {
  stats: any;
  loading: boolean;
  isAdmin?: boolean;
}

export default function StatsGrid({ stats, loading, isAdmin = false }: StatsGridProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <Skeleton className="h-12 w-12 rounded-lg mb-4" />
              <Skeleton className="h-8 w-20 mb-2" />
              <Skeleton className="h-4 w-24" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!stats) return null;

  const adminStats = [
    {
      title: "Empresas Ativas",
      value: stats.companies,
      icon: "fas fa-building",
      color: "blue",
      change: "Ativo",
    },
    {
      title: "Usuários Totais",
      value: stats.users.toLocaleString(),
      icon: "fas fa-users",
      color: "green",
      change: "+12%",
    },
    {
      title: "Receita Mensal",
      value: `R$ ${(stats.revenue / 1000).toFixed(0)}K`,
      icon: "fas fa-dollar-sign",
      color: "purple",
      change: "+23%",
    },
    {
      title: "Problemas Ativos",
      value: stats.issues,
      icon: "fas fa-exclamation-triangle",
      color: "red",
      change: "-5%",
    },
  ];

  const companyStats = [
    {
      title: "Receita Mensal",
      value: `R$ ${(stats.revenue / 1000).toFixed(1)}K`,
      icon: "fas fa-dollar-sign",
      color: "green",
      change: "+12%",
    },
    {
      title: "Leads Ativos",
      value: stats.leads.toLocaleString(),
      icon: "fas fa-users",
      color: "blue",
      change: "+8%",
    },
    {
      title: "Automações Ativas",
      value: stats.automations,
      icon: "fas fa-robot",
      color: "purple",
      change: "+23%",
    },
    {
      title: "Taxa Conversão",
      value: `${stats.conversions}%`,
      icon: "fas fa-chart-line",
      color: "orange",
      change: "+15%",
    },
  ];

  const statsToShow = isAdmin ? adminStats : companyStats;

  const getColorClasses = (color: string) => {
    const colors = {
      blue: "bg-blue-100 text-blue-600",
      green: "bg-green-100 text-green-600",
      purple: "bg-purple-100 text-dnx-primary",
      orange: "bg-orange-100 text-orange-600",
      red: "bg-red-100 text-red-600",
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  const getChangeColor = (change: string) => {
    if (change.startsWith("+")) return "text-green-600";
    if (change.startsWith("-")) return "text-red-600";
    return "text-blue-600";
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statsToShow.map((stat, index) => (
        <Card key={index} className="hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 bg-white/80 backdrop-blur-sm border-purple-100 animate-scale-in" style={{animationDelay: `${index * 0.1}s`}}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${getColorClasses(stat.color)} shadow-lg animate-glow`}>
                <i className={`${stat.icon} text-lg`}></i>
              </div>
              <span className={`text-sm font-bold px-2 py-1 rounded-full ${getChangeColor(stat.change)} bg-opacity-10`}>
                {stat.change}
              </span>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-2 animate-pulse">{stat.value}</div>
            <p className="text-gray-600 text-sm font-medium">{stat.title}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
