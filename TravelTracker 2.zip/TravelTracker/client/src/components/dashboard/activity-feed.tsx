import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

interface ActivityFeedProps {
  activities: any[];
  loading: boolean;
}

export default function ActivityFeed({ activities, loading }: ActivityFeedProps) {
  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Atividades Recentes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-start space-x-3">
                <Skeleton className="w-8 h-8 rounded-full" />
                <div className="flex-1">
                  <Skeleton className="h-4 w-3/4 mb-1" />
                  <Skeleton className="h-3 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getActivityIcon = (type: string) => {
    const icons = {
      conversion: { icon: "fas fa-check", color: "bg-green-100 text-green-600" },
      workflow: { icon: "fas fa-robot", color: "bg-blue-100 text-blue-600" },
      lead: { icon: "fas fa-user-plus", color: "bg-purple-100 text-dnx-primary" },
      default: { icon: "fas fa-info-circle", color: "bg-gray-100 text-gray-600" },
    };
    return icons[type as keyof typeof icons] || icons.default;
  };

  return (
    <Card className="shadow-xl bg-white/80 backdrop-blur-sm border-purple-100 animate-scale-in">
      <CardHeader>
        <CardTitle className="flex items-center">
          <i className="fas fa-history text-dnx-primary mr-2"></i>
          Atividades Recentes
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities && activities.length > 0 ? (
            activities.slice(0, 5).map((activity, index) => {
              const { icon, color } = getActivityIcon(activity.type);
              return (
                <div key={activity.id} className="flex items-start space-x-4 p-3 rounded-xl bg-gradient-to-r from-white to-gray-50 hover:shadow-md transition-all duration-200 animate-slide-up" style={{animationDelay: `${index * 0.1}s`}}>
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${color} shadow-md`}>
                    <i className={`${icon} text-sm`}></i>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">{activity.description}</p>
                    <p className="text-xs text-gray-500 mt-1 flex items-center">
                      <i className="fas fa-clock mr-1"></i>
                      {formatDistanceToNow(new Date(activity.createdAt), { 
                        addSuffix: true, 
                        locale: ptBR 
                      })}
                    </p>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-inbox text-gray-400 text-2xl"></i>
              </div>
              <p className="text-gray-500 font-medium">Nenhuma atividade recente</p>
              <p className="text-gray-400 text-sm mt-1">As atividades aparecerão aqui</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
