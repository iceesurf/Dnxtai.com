import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  if (!user) return null;

  const isAdmin = user.role === "admin";

  const navigation = isAdmin
    ? [
        { name: "Overview", href: "/admin", icon: "fas fa-chart-pie" },
        { name: "Empresas", href: "/admin/companies", icon: "fas fa-building" },
        { name: "Usuários", href: "/admin/users", icon: "fas fa-users" },
        { name: "Faturamento", href: "/admin/billing", icon: "fas fa-credit-card" },
        { name: "Sistema", href: "/admin/system", icon: "fas fa-server" },
      ]
    : [
        { name: "Dashboard", href: "/dashboard", icon: "fas fa-tachometer-alt" },
        { name: "Workflows", href: "/workflows", icon: "fas fa-project-diagram" },
        { name: "CRM", href: "/crm", icon: "fas fa-users" },
        { name: "Chatbot", href: "/chatbot", icon: "fas fa-robot" },
        { name: "Analytics", href: "/analytics", icon: "fas fa-chart-bar" },
        { name: "Configurações", href: "/settings", icon: "fas fa-cog" },
      ];

  return (
    <div className={cn(
      "w-64 min-h-screen p-6",
      isAdmin ? "bg-gradient-to-b from-gray-900 to-gray-800" : "bg-white/60 backdrop-blur-sm border-r border-purple-100"
    )}>
      {isAdmin && (
        <div className="mb-8">
          <div className="flex items-center space-x-4 p-4 bg-white/10 rounded-xl backdrop-blur-sm">
            <div className="w-12 h-12 bg-dnx-gradient rounded-xl flex items-center justify-center shadow-lg">
              <span className="text-white font-bold">ADM</span>
            </div>
            <div>
              <h3 className="text-white font-semibold">DNXTAI Admin</h3>
              <p className="text-gray-300 text-sm">Super Administrador</p>
            </div>
          </div>
        </div>
      )}

      <nav className="space-y-3">
        {navigation.map((item, index) => {
          const isActive = location === item.href || (item.href !== "/dashboard" && location.startsWith(item.href));
          
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center space-x-4 px-4 py-3 rounded-xl font-medium transition-all duration-300 transform hover:scale-105",
                isActive
                  ? isAdmin 
                    ? "bg-dnx-gradient text-white shadow-lg" 
                    : "bg-dnx-gradient text-white shadow-lg"
                  : isAdmin
                  ? "text-gray-300 hover:text-white hover:bg-white/10 backdrop-blur-sm"
                  : "text-gray-700 hover:text-dnx-primary hover:bg-purple-50 hover:shadow-md"
              )}
              style={{animationDelay: `${index * 0.1}s`}}
            >
              <i className={`${item.icon} text-lg`}></i>
              <span className="font-semibold">{item.name}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
