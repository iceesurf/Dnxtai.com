# Guia de Deploy - DNXTAI Platform

## Preparação para Hospedagem

A plataforma DNXTAI está completamente pronta para deploy em qualquer provedor de hospedagem. Todos os arquivos de configuração necessários foram criados.

### Arquivos de Deploy Incluídos

- `Dockerfile` - Para containerização
- `vercel.json` - Configuração para Vercel
- `netlify.toml` - Configuração para Netlify
- `railway.toml` - Configuração para Railway
- `.env.example` - Exemplo de variáveis de ambiente
- `deploy.sh` - Script automatizado de deploy

## Opções de Hospedagem

### 1. Vercel (Recomendado)
```bash
npm install -g vercel
vercel login
vercel --prod
```

### 2. Railway
```bash
npm install -g @railway/cli
railway login
railway link
railway up
```

### 3. Netlify
1. Conecte seu repositório no painel da Netlify
2. Configure:
   - Build command: `npm run build`
   - Publish directory: `client/dist`

### 4. Docker (Qualquer provedor)
```bash
docker build -t dnxtai .
docker run -p 5000:5000 dnxtai
```

### 5. Deploy Automatizado
```bash
chmod +x deploy.sh
./deploy.sh vercel    # ou railway, docker
```

## Configuração de Ambiente

### Variáveis Obrigatórias
```env
NODE_ENV=production
PORT=5000
JWT_SECRET=sua_chave_secreta_jwt
```

### Variáveis Opcionais
```env
DATABASE_URL=postgresql://...
FRONTEND_URL=https://seudominio.com
ALLOWED_ORIGINS=https://seudominio.com
```

## Verificação Pós-Deploy

### Endpoints de Health Check
- `GET /api/health` - Status básico
- `GET /api/status` - Status detalhado

### Contas de Teste
- **Admin**: admin@dnxtai.com / senha123
- **Empresa**: user@empresa.com / senha123

## Estrutura de Produção

```
dist/
├── server.js         # Backend compilado
└── client/           # Frontend estático
    ├── index.html
    ├── assets/
    └── ...
```

## Performance e Otimizações

- Build otimizado com tree-shaking
- Assets com cache headers
- Compressão gzip/brotli
- Bundle splitting automático

## Monitoramento

A aplicação inclui endpoints para monitoramento:
- Uptime
- Uso de memória
- Versão da aplicação
- Status dos serviços

## Próximos Passos

1. Escolha o provedor de hospedagem
2. Configure as variáveis de ambiente
3. Execute o deploy
4. Teste a aplicação em produção
5. Configure domínio personalizado (opcional)

A plataforma está pronta para produção com todas as melhores práticas implementadas.