import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

export default function CRM() {
  const [, setLocation] = useLocation();
  const { user, isLoading } = useAuth();

  const { data: leads, isLoading: leadsLoading } = useQuery({
    queryKey: ["/api/leads"],
    enabled: !!user && user.role !== "admin",
  });

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/login");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-2xl text-dnx-primary"></i>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const mockLeads = [
    {
      id: 1,
      name: "João Silva",
      email: "joao@email.com",
      phone: "(11) 99999-9999",
      status: "new",
      source: "Website",
      value: 5000,
      created: "2024-06-24",
    },
    {
      id: 2,
      name: "Maria Santos",
      email: "maria@email.com",
      phone: "(11) 88888-8888",
      status: "qualified",
      source: "Facebook Ads",
      value: 8500,
      created: "2024-06-23",
    },
    {
      id: 3,
      name: "Pedro Costa",
      email: "pedro@email.com",
      phone: "(11) 77777-7777",
      status: "proposal",
      source: "Google Ads",
      value: 12000,
      created: "2024-06-22",
    },
  ];

  const getStatusBadge = (status: string) => {
    const variants = {
      new: "secondary",
      qualified: "default",
      proposal: "destructive",
      won: "default",
      lost: "secondary",
    };
    return variants[status as keyof typeof variants] || "secondary";
  };

  const getStatusLabel = (status: string) => {
    const labels = {
      new: "Novo",
      qualified: "Qualificado", 
      proposal: "Proposta",
      won: "Ganho",
      lost: "Perdido",
    };
    return labels[status as keyof typeof labels] || status;
  };

  const getStatusIcon = (status: string) => {
    const icons = {
      new: "fas fa-star",
      qualified: "fas fa-check",
      proposal: "fas fa-file-contract",
      won: "fas fa-trophy",
      lost: "fas fa-times",
    };
    return icons[status as keyof typeof icons] || "fas fa-circle";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-purple-50/30 to-gray-100">
      <Header />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <div className="mb-8 animate-slide-up">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-900 to-dnx-primary bg-clip-text text-transparent">
                  CRM Avançado
                </h1>
                <p className="text-gray-600 mt-2 text-lg">
                  Gerencie leads e clientes com inteligência artificial
                </p>
              </div>
              <div className="flex space-x-3">
                <Button variant="outline" className="hover:bg-purple-50">
                  <i className="fas fa-upload mr-2"></i>
                  Importar
                </Button>
                <Button className="bg-dnx-gradient hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                  <i className="fas fa-plus mr-2"></i>
                  Novo Lead
                </Button>
              </div>
            </div>
          </div>

          {/* Filtros e Busca */}
          <Card className="mb-6 shadow-lg bg-white/80 backdrop-blur-sm border-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="flex-1">
                  <Input 
                    placeholder="Buscar leads por nome, email ou telefone..." 
                    className="bg-white/60"
                  />
                </div>
                <Button variant="outline" className="hover:bg-purple-50">
                  <i className="fas fa-filter mr-2"></i>
                  Filtros
                </Button>
                <Button variant="outline" className="hover:bg-blue-50">
                  <i className="fas fa-sort mr-2"></i>
                  Ordenar
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Pipeline de Vendas */}
          <div className="grid lg:grid-cols-5 gap-4 mb-8">
            {[
              { status: "new", label: "Novos", count: 12, color: "bg-blue-500" },
              { status: "qualified", label: "Qualificados", count: 8, color: "bg-green-500" },
              { status: "proposal", label: "Proposta", count: 5, color: "bg-yellow-500" },
              { status: "won", label: "Ganhos", count: 15, color: "bg-purple-500" },
              { status: "lost", label: "Perdidos", count: 3, color: "bg-gray-500" },
            ].map((stage, index) => (
              <Card key={stage.status} className="hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 bg-white/80 backdrop-blur-sm animate-scale-in" style={{animationDelay: `${index * 0.1}s`}}>
                <CardContent className="p-4 text-center">
                  <div className={`w-12 h-12 ${stage.color} rounded-full flex items-center justify-center mx-auto mb-3`}>
                    <span className="text-white font-bold text-lg">{stage.count}</span>
                  </div>
                  <h3 className="font-semibold text-gray-900">{stage.label}</h3>
                  <p className="text-sm text-gray-600">leads</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Lista de Leads */}
          <Card className="shadow-xl bg-white/80 backdrop-blur-sm border-purple-100">
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-users text-dnx-primary mr-2"></i>
                Leads Recentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockLeads.map((lead, index) => (
                  <div key={lead.id} className="flex items-center justify-between p-4 bg-gradient-to-r from-white to-gray-50 rounded-xl border border-purple-100 hover:shadow-md transition-all duration-200 animate-slide-up" style={{animationDelay: `${index * 0.1}s`}}>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-dnx-gradient rounded-full flex items-center justify-center">
                        <span className="text-white font-bold">
                          {lead.name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">{lead.name}</h4>
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <span className="flex items-center">
                            <i className="fas fa-envelope mr-1"></i>
                            {lead.email}
                          </span>
                          <span className="flex items-center">
                            <i className="fas fa-phone mr-1"></i>
                            {lead.phone}
                          </span>
                          <span className="flex items-center">
                            <i className="fas fa-chart-line mr-1"></i>
                            {lead.source}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="text-lg font-bold text-green-600">
                          R$ {lead.value.toLocaleString()}
                        </div>
                        <div className="text-sm text-gray-500">{lead.created}</div>
                      </div>
                      <Badge variant={getStatusBadge(lead.status)} className="flex items-center">
                        <i className={`${getStatusIcon(lead.status)} mr-1 text-xs`}></i>
                        {getStatusLabel(lead.status)}
                      </Badge>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" className="hover:bg-purple-50">
                          <i className="fas fa-edit"></i>
                        </Button>
                        <Button variant="outline" size="sm" className="hover:bg-blue-50">
                          <i className="fas fa-eye"></i>
                        </Button>
                        <Button variant="outline" size="sm" className="hover:bg-green-50">
                          <i className="fas fa-phone"></i>
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}