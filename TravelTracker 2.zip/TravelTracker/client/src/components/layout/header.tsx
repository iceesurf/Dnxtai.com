import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Header() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
  };

  return (
    <nav className="bg-white/80 backdrop-blur-lg shadow-lg border-b border-purple-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center group">
              <div className="w-12 h-12 bg-dnx-gradient rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 transform group-hover:scale-105">
                <span className="text-white font-bold text-lg">DN</span>
              </div>
              <span className="ml-3 text-2xl font-bold bg-gradient-to-r from-dnx-primary to-dnx-secondary bg-clip-text text-transparent">DNXTAI</span>
            </Link>
            
            {!user && (
              <div className="hidden md:ml-12 md:flex md:space-x-8">
                <a href="#home" className="text-dnx-primary border-b-2 border-dnx-primary px-2 pt-1 pb-4 text-sm font-semibold hover:bg-purple-50 rounded-t-lg transition-all duration-200">
                  <i className="fas fa-home mr-1"></i>
                  Início
                </a>
                <a href="#features" className="text-gray-600 hover:text-dnx-primary px-2 pt-1 pb-4 text-sm font-medium transition-all duration-200 hover:bg-purple-50 rounded-t-lg">
                  <i className="fas fa-rocket mr-1"></i>
                  Recursos
                </a>
                <a href="#pricing" className="text-gray-600 hover:text-dnx-primary px-2 pt-1 pb-4 text-sm font-medium transition-all duration-200 hover:bg-purple-50 rounded-t-lg">
                  <i className="fas fa-tags mr-1"></i>
                  Preços
                </a>
                <a href="#demo" className="text-gray-600 hover:text-dnx-primary px-2 pt-1 pb-4 text-sm font-medium transition-all duration-200 hover:bg-purple-50 rounded-t-lg">
                  <i className="fas fa-play mr-1"></i>
                  Demo
                </a>
              </div>
            )}
          </div>
          
          <div className="flex items-center space-x-4">
            {user ? (
              <>
                <div className="hidden md:flex items-center space-x-3">
                  <div className="bg-purple-100 px-3 py-1 rounded-full">
                    <span className="text-purple-700 text-sm font-medium flex items-center">
                      <i className={`fas ${user.role === "admin" ? "fa-crown" : "fa-user"} mr-2`}></i>
                      {user.role === "admin" ? "Admin" : "Usuário"}
                    </span>
                  </div>
                  <div className="bg-green-100 px-3 py-1 rounded-full">
                    <span className="text-green-700 text-sm font-medium flex items-center">
                      <span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
                      Online
                    </span>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="w-12 h-12 rounded-full p-0 hover:shadow-lg transition-all duration-200">
                      <div className="w-10 h-10 bg-dnx-gradient rounded-full flex items-center justify-center shadow-md">
                        <span className="text-white font-bold text-sm">
                          {user.email.charAt(0).toUpperCase()}
                        </span>
                      </div>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 bg-white/95 backdrop-blur-sm border-purple-100">
                    <div className="px-3 py-2 border-b border-purple-100">
                      <p className="text-sm font-medium text-gray-900">{user.email}</p>
                      <p className="text-xs text-gray-500">{user.role === "admin" ? "Administrador" : "Usuário"}</p>
                    </div>
                    <DropdownMenuItem onClick={handleLogout} className="text-red-600 hover:bg-red-50">
                      <i className="fas fa-sign-out-alt mr-2"></i>
                      Sair da Conta
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <>
                <Button variant="ghost" asChild className="hover:bg-purple-50 hover:text-dnx-primary">
                  <Link href="/login">
                    <i className="fas fa-sign-in-alt mr-2"></i>
                    Entrar
                  </Link>
                </Button>
                <Button asChild className="bg-dnx-gradient hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                  <Link href="/login">
                    <i className="fas fa-rocket mr-2"></i>
                    Começar Grátis
                  </Link>
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
