import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema } from "@shared/schema";
import { registerHealthRoutes } from "./health";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "dnxtai_secret_key_2024";

interface AuthenticatedRequest extends Request {
  user?: {
    id: number;
    email: string;
    role: string;
    companyId?: number;
  };
}

function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, decoded: any) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = decoded;
    next();
  });
}

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check routes
  registerHealthRoutes(app);

  // Authentication routes
  app.post('/api/login', async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      const user = await storage.validateUser(email, password);
      if (!user) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const token = jwt.sign(
        { 
          id: user.id, 
          email: user.email, 
          role: user.role,
          companyId: user.companyId 
        },
        JWT_SECRET,
        { expiresIn: '8h' }
      );

      res.json({ 
        token, 
        user: { 
          id: user.id, 
          email: user.email, 
          role: user.role,
          companyId: user.companyId 
        } 
      });
    } catch (error) {
      res.status(400).json({ error: 'Invalid request data' });
    }
  });

  // Company routes
  app.get('/api/companies', authenticateToken, requireAdmin, async (req, res) => {
    try {
      const companies = await storage.getAllCompanies();
      res.json(companies);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch companies' });
    }
  });

  app.post('/api/companies/:id/status', authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      await storage.updateCompanyStatus(parseInt(id), status);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update company status' });
    }
  });

  // Dashboard routes
  app.get('/api/dashboard/stats', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      if (req.user?.role === 'admin') {
        const stats = await storage.getAdminStats();
        res.json(stats);
      } else if (req.user?.companyId) {
        const stats = await storage.getCompanyStats(req.user.companyId);
        res.json(stats);
      } else {
        res.status(403).json({ error: 'No company access' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch stats' });
    }
  });

  app.get('/api/dashboard/activities', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      if (!req.user?.companyId) {
        return res.status(403).json({ error: 'Company access required' });
      }
      
      const activities = await storage.getActivitiesByCompany(req.user.companyId);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch activities' });
    }
  });

  // Leads routes
  app.get('/api/leads', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      if (!req.user?.companyId) {
        return res.status(403).json({ error: 'Company access required' });
      }
      
      const leads = await storage.getLeadsByCompany(req.user.companyId);
      res.json(leads);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch leads' });
    }
  });

  // Workflows routes
  app.get('/api/workflows', authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      if (!req.user?.companyId) {
        return res.status(403).json({ error: 'Company access required' });
      }
      
      const workflows = await storage.getWorkflowsByCompany(req.user.companyId);
      res.json(workflows);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch workflows' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
