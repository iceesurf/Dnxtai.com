# DNXTAI - Business Automation Platform

## Overview

DNXTAI is a comprehensive business automation platform that combines AI-powered workflows, CRM, chatbots, and analytics in one integrated solution. The application features a multi-tenant architecture supporting both regular business users and super administrators, with role-based access control and company-specific data isolation.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom DNXTAI brand colors
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Development**: Hot reload with Vite middleware integration
- **Authentication**: JWT-based authentication with role-based access control
- **Password Security**: bcrypt for password hashing

### Database Layer
- **ORM**: Drizzle ORM for type-safe database interactions
- **Database**: PostgreSQL (configured for Neon serverless)
- **Migrations**: Drizzle Kit for schema management
- **Schema Location**: `shared/schema.ts` for shared type definitions

## Key Components

### Authentication System
- JWT token-based authentication
- Role-based access control (admin/user)
- Company-specific user isolation
- Secure password hashing with bcrypt
- Context-based authentication state management

### Multi-Tenancy
- Company-based data isolation
- User association with specific companies
- Admin users can access all companies
- Company-specific workflows, leads, and activities

### Data Models
- **Companies**: Business entities with plans and status
- **Users**: Account holders with roles and company associations
- **Workflows**: Automation processes per company
- **Leads**: Customer prospect management
- **Activities**: Audit trail and activity logging

### UI Components
- Comprehensive component library based on shadcn/ui
- Responsive design with mobile-first approach
- Consistent brand theming with CSS custom properties
- Accessible components using Radix UI primitives

## Data Flow

### Authentication Flow
1. User submits credentials to `/api/login`
2. Server validates credentials against database
3. JWT token generated and returned with user data
4. Token stored in localStorage for subsequent requests
5. Protected routes verify token before access

### Application State Flow
1. React Query manages server state and caching
2. Auth context provides user state across components
3. Protected routes redirect unauthenticated users
4. Role-based rendering for admin vs user interfaces

### Data Access Pattern
1. Frontend makes API requests through fetch
2. Server routes handle authentication middleware
3. Database queries through Drizzle ORM
4. Type-safe responses with shared schema definitions

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Neon PostgreSQL driver
- **@tanstack/react-query**: Server state management
- **drizzle-orm**: Type-safe database ORM
- **bcryptjs**: Password hashing
- **jsonwebtoken**: JWT authentication
- **wouter**: Lightweight React router

### UI Dependencies
- **@radix-ui/**: Comprehensive accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Tools
- **tsx**: TypeScript execution for development
- **esbuild**: Fast JavaScript bundler for production
- **vite**: Frontend build tool and development server

## Deployment Strategy

### Development Environment
- Replit-based development with hot reload
- Vite development server with Express.js backend
- PostgreSQL database through Replit modules
- Environment variables for database connection

### Production Build
- Vite builds optimized frontend bundle
- esbuild compiles server code for Node.js
- Static assets served from Express.js
- Database migrations through Drizzle Kit

### Configuration
- Environment-based configuration (development/production)
- Database URL from environment variables
- JWT secret configuration
- Build targets: client static files and server bundle

## Changelog
- June 24, 2025: Initial setup and core platform development
- June 24, 2025: Production deployment preparation complete
  - Added Docker, Vercel, Railway, Netlify configurations
  - Created deployment scripts and documentation
  - Added health check endpoints
  - Configured production build process
  - Ready for hosting deployment
- June 24, 2025: Enhanced design and functionality upgrade
  - Implemented modern glassmorphism design with animations
  - Enhanced landing page with floating elements and gradients
  - Improved dashboard with better visual hierarchy
  - Added comprehensive Workflows and CRM pages
  - Enhanced header with better user experience
  - Added backdrop blur effects and hover animations
  - Integrated PostgreSQL database successfully

## User Preferences

Preferred communication style: Simple, everyday language.