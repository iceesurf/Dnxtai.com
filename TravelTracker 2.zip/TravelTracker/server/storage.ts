import { companies, users, workflows, leads, activities, type Company, type User, type Workflow, type Lead, type Activity, type InsertCompany, type InsertUser, type InsertWorkflow, type InsertLead, type InsertActivity } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

export interface IStorage {
  // Company methods
  getCompany(id: number): Promise<Company | undefined>;
  getCompanyByEmail(email: string): Promise<Company | undefined>;
  createCompany(company: InsertCompany): Promise<Company>;
  getAllCompanies(): Promise<Company[]>;
  updateCompanyStatus(id: number, status: string): Promise<void>;

  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUsersByCompany(companyId: number): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  validateUser(email: string, password: string): Promise<User | null>;

  // Workflow methods
  getWorkflowsByCompany(companyId: number): Promise<Workflow[]>;
  createWorkflow(workflow: InsertWorkflow): Promise<Workflow>;

  // Lead methods
  getLeadsByCompany(companyId: number): Promise<Lead[]>;
  createLead(lead: InsertLead): Promise<Lead>;

  // Activity methods
  getActivitiesByCompany(companyId: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;

  // Stats methods
  getCompanyStats(companyId: number): Promise<{
    revenue: number;
    leads: number;
    automations: number;
    conversions: number;
  }>;

  getAdminStats(): Promise<{
    companies: number;
    users: number;
    revenue: number;
    issues: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    this.initializeData();
  }

  private async initializeData() {
    try {
      // Check if admin user exists
      const existingAdmin = await this.getUserByEmail("admin@dnxtai.com");
      if (existingAdmin) return;

      // Create demo company
      const demoCompany = await this.createCompany({
        name: "Empresa Demo",
        email: "demo@empresa.com",
        plan: "pro",
        status: "active",
      });

      // Create admin user
      const hashedPassword = await bcrypt.hash("senha123", 10);
      await this.createUser({
        email: "admin@dnxtai.com",
        password: hashedPassword,
        role: "admin",
        companyId: null,
      });

      // Create demo company user
      await this.createUser({
        email: "user@empresa.com",
        password: hashedPassword,
        role: "user",
        companyId: demoCompany.id,
      });

      // Create sample data
      await this.createLead({
        name: "João Silva",
        email: "joao@email.com",
        status: "new",
        companyId: demoCompany.id,
      });

      await this.createActivity({
        description: "Novo lead convertido via chatbot",
        type: "conversion",
        companyId: demoCompany.id,
      });

      await this.createWorkflow({
        name: "Email de Boas-vindas",
        status: "active",
        companyId: demoCompany.id,
      });

      console.log("Database initialized with demo data");
    } catch (error) {
      console.error("Error initializing database:", error);
    }
  }

  async getCompany(id: number): Promise<Company | undefined> {
    const [company] = await db.select().from(companies).where(eq(companies.id, id));
    return company || undefined;
  }

  async getCompanyByEmail(email: string): Promise<Company | undefined> {
    const [company] = await db.select().from(companies).where(eq(companies.email, email));
    return company || undefined;
  }

  async createCompany(insertCompany: InsertCompany): Promise<Company> {
    const [company] = await db
      .insert(companies)
      .values({
        name: insertCompany.name,
        email: insertCompany.email,
        plan: insertCompany.plan || "free",
        status: insertCompany.status || "active",
      })
      .returning();
    return company;
  }

  async getAllCompanies(): Promise<Company[]> {
    return await db.select().from(companies);
  }

  async updateCompanyStatus(id: number, status: string): Promise<void> {
    await db.update(companies).set({ status }).where(eq(companies.id, id));
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUsersByCompany(companyId: number): Promise<User[]> {
    return await db.select().from(users).where(eq(users.companyId, companyId));
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        email: insertUser.email,
        password: insertUser.password,
        role: insertUser.role || "user",
        companyId: insertUser.companyId || null,
      })
      .returning();
    return user;
  }

  async validateUser(email: string, password: string): Promise<User | null> {
    const user = await this.getUserByEmail(email);
    if (!user) return null;

    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  async getWorkflowsByCompany(companyId: number): Promise<Workflow[]> {
    return await db.select().from(workflows).where(eq(workflows.companyId, companyId));
  }

  async createWorkflow(insertWorkflow: InsertWorkflow): Promise<Workflow> {
    const [workflow] = await db
      .insert(workflows)
      .values({
        name: insertWorkflow.name,
        status: insertWorkflow.status || "draft",
        companyId: insertWorkflow.companyId,
      })
      .returning();
    return workflow;
  }

  async getLeadsByCompany(companyId: number): Promise<Lead[]> {
    return await db.select().from(leads).where(eq(leads.companyId, companyId));
  }

  async createLead(insertLead: InsertLead): Promise<Lead> {
    const [lead] = await db
      .insert(leads)
      .values({
        name: insertLead.name,
        email: insertLead.email,
        status: insertLead.status || "new",
        companyId: insertLead.companyId,
      })
      .returning();
    return lead;
  }

  async getActivitiesByCompany(companyId: number): Promise<Activity[]> {
    return await db.select().from(activities).where(eq(activities.companyId, companyId));
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const [activity] = await db
      .insert(activities)
      .values({
        description: insertActivity.description,
        type: insertActivity.type,
        companyId: insertActivity.companyId,
      })
      .returning();
    return activity;
  }

  async getCompanyStats(companyId: number): Promise<{
    revenue: number;
    leads: number;
    automations: number;
    conversions: number;
  }> {
    const companyLeads = await this.getLeadsByCompany(companyId);
    const companyWorkflows = await this.getWorkflowsByCompany(companyId);
    
    return {
      revenue: 45200,
      leads: companyLeads.length,
      automations: companyWorkflows.length,
      conversions: 92.4,
    };
  }

  async getAdminStats(): Promise<{
    companies: number;
    users: number;
    revenue: number;
    issues: number;
  }> {
    const allCompanies = await this.getAllCompanies();
    const allUsers = await db.select().from(users);
    
    return {
      companies: allCompanies.length,
      users: allUsers.length,
      revenue: 187000,
      issues: 3,
    };
  }
}

export class MemStorage implements IStorage {
  private companies: Map<number, Company>;
  private users: Map<number, User>;
  private workflows: Map<number, Workflow>;
  private leads: Map<number, Lead>;
  private activities: Map<number, Activity>;
  private currentCompanyId: number;
  private currentUserId: number;
  private currentWorkflowId: number;
  private currentLeadId: number;
  private currentActivityId: number;

  constructor() {
    this.companies = new Map();
    this.users = new Map();
    this.workflows = new Map();
    this.leads = new Map();
    this.activities = new Map();
    this.currentCompanyId = 1;
    this.currentUserId = 1;
    this.currentWorkflowId = 1;
    this.currentLeadId = 1;
    this.currentActivityId = 1;

    this.initializeData();
  }

  private async initializeData() {
    // Create demo company
    const demoCompany: Company = {
      id: this.currentCompanyId++,
      name: "Empresa Demo",
      email: "demo@empresa.com",
      plan: "pro",
      status: "active",
      createdAt: new Date(),
    };
    this.companies.set(demoCompany.id, demoCompany);

    // Create admin user
    const hashedPassword = await bcrypt.hash("senha123", 10);
    const adminUser: User = {
      id: this.currentUserId++,
      email: "admin@dnxtai.com",
      password: hashedPassword,
      role: "admin",
      companyId: null,
      createdAt: new Date(),
    };
    this.users.set(adminUser.id, adminUser);

    // Create demo company user
    const demoUser: User = {
      id: this.currentUserId++,
      email: "user@empresa.com",
      password: hashedPassword,
      role: "user",
      companyId: demoCompany.id,
      createdAt: new Date(),
    };
    this.users.set(demoUser.id, demoUser);

    // Create sample data
    const sampleLead: Lead = {
      id: this.currentLeadId++,
      name: "João Silva",
      email: "joao@email.com",
      status: "new",
      companyId: demoCompany.id,
      createdAt: new Date(),
    };
    this.leads.set(sampleLead.id, sampleLead);

    const sampleActivity: Activity = {
      id: this.currentActivityId++,
      description: "Novo lead convertido via chatbot",
      type: "conversion",
      companyId: demoCompany.id,
      createdAt: new Date(),
    };
    this.activities.set(sampleActivity.id, sampleActivity);

    const sampleWorkflow: Workflow = {
      id: this.currentWorkflowId++,
      name: "Email de Boas-vindas",
      status: "active",
      companyId: demoCompany.id,
      createdAt: new Date(),
    };
    this.workflows.set(sampleWorkflow.id, sampleWorkflow);
  }

  async getCompany(id: number): Promise<Company | undefined> {
    return this.companies.get(id);
  }

  async getCompanyByEmail(email: string): Promise<Company | undefined> {
    return Array.from(this.companies.values()).find(c => c.email === email);
  }

  async createCompany(insertCompany: InsertCompany): Promise<Company> {
    const company: Company = {
      id: this.currentCompanyId++,
      name: insertCompany.name,
      email: insertCompany.email,
      plan: insertCompany.plan || "free",
      status: insertCompany.status || "active",
      createdAt: new Date(),
    };
    this.companies.set(company.id, company);
    return company;
  }

  async getAllCompanies(): Promise<Company[]> {
    return Array.from(this.companies.values());
  }

  async updateCompanyStatus(id: number, status: string): Promise<void> {
    const company = this.companies.get(id);
    if (company) {
      company.status = status;
      this.companies.set(id, company);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.email === email);
  }

  async getUsersByCompany(companyId: number): Promise<User[]> {
    return Array.from(this.users.values()).filter(u => u.companyId === companyId);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      id: this.currentUserId++,
      email: insertUser.email,
      password: insertUser.password,
      role: insertUser.role || "user",
      companyId: insertUser.companyId || null,
      createdAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }

  async validateUser(email: string, password: string): Promise<User | null> {
    const user = await this.getUserByEmail(email);
    if (!user) return null;

    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  async getWorkflowsByCompany(companyId: number): Promise<Workflow[]> {
    return Array.from(this.workflows.values()).filter(w => w.companyId === companyId);
  }

  async createWorkflow(insertWorkflow: InsertWorkflow): Promise<Workflow> {
    const workflow: Workflow = {
      id: this.currentWorkflowId++,
      name: insertWorkflow.name,
      status: insertWorkflow.status || "draft",
      companyId: insertWorkflow.companyId,
      createdAt: new Date(),
    };
    this.workflows.set(workflow.id, workflow);
    return workflow;
  }

  async getLeadsByCompany(companyId: number): Promise<Lead[]> {
    return Array.from(this.leads.values()).filter(l => l.companyId === companyId);
  }

  async createLead(insertLead: InsertLead): Promise<Lead> {
    const lead: Lead = {
      id: this.currentLeadId++,
      name: insertLead.name,
      email: insertLead.email,
      status: insertLead.status || "new",
      companyId: insertLead.companyId,
      createdAt: new Date(),
    };
    this.leads.set(lead.id, lead);
    return lead;
  }

  async getActivitiesByCompany(companyId: number): Promise<Activity[]> {
    return Array.from(this.activities.values()).filter(a => a.companyId === companyId);
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const activity: Activity = {
      ...insertActivity,
      id: this.currentActivityId++,
      createdAt: new Date(),
    };
    this.activities.set(activity.id, activity);
    return activity;
  }

  async getCompanyStats(companyId: number): Promise<{
    revenue: number;
    leads: number;
    automations: number;
    conversions: number;
  }> {
    const leads = await this.getLeadsByCompany(companyId);
    const workflows = await this.getWorkflowsByCompany(companyId);
    
    return {
      revenue: 45200,
      leads: leads.length,
      automations: workflows.length,
      conversions: 92.4,
    };
  }

  async getAdminStats(): Promise<{
    companies: number;
    users: number;
    revenue: number;
    issues: number;
  }> {
    return {
      companies: this.companies.size,
      users: this.users.size,
      revenue: 187000,
      issues: 3,
    };
  }
}

export const storage = new DatabaseStorage();
