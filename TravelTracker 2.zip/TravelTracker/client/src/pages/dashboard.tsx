import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import StatsGrid from "@/components/dashboard/stats-grid";
import ActivityFeed from "@/components/dashboard/activity-feed";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { user, isLoading } = useAuth();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    enabled: !!user,
  });

  const { data: activities, isLoading: activitiesLoading } = useQuery({
    queryKey: ["/api/dashboard/activities"],
    enabled: !!user && user.role !== "admin",
  });

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/login");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-2xl text-dnx-primary"></i>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-purple-50/30 to-gray-100">
      <Header />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <div className="mb-8 animate-slide-up">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-900 to-dnx-primary bg-clip-text text-transparent">
                  {user.role === "admin" ? "Painel Administrativo" : "Dashboard"}
                </h1>
                <p className="text-gray-600 mt-2 text-lg">
                  {user.role === "admin" 
                    ? "Gerenciamento centralizado da plataforma DNXTAI"
                    : "Visão geral do seu negócio"
                  }
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="bg-white/60 backdrop-blur-sm px-4 py-2 rounded-xl border border-purple-100">
                  <span className="text-sm text-gray-600">Bem-vindo, </span>
                  <span className="font-semibold text-dnx-primary">{user.email.split('@')[0]}</span>
                </div>
                {user.role !== "admin" && (
                  <div className="bg-green-100 px-3 py-1 rounded-full">
                    <span className="text-green-700 text-sm font-medium flex items-center">
                      <span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
                      Online
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <StatsGrid stats={stats} loading={statsLoading} />

          <div className="grid lg:grid-cols-2 gap-8 mt-8">
            {/* Enhanced Chart Area */}
            <Card className="shadow-xl bg-white/80 backdrop-blur-sm border-purple-100 animate-scale-in">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-chart-line text-dnx-primary mr-2"></i>
                  Performance Semanal
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-dnx-gradient rounded-xl flex items-end justify-between p-6 relative overflow-hidden">
                  <div className="absolute inset-0 bg-white/10 backdrop-blur-sm"></div>
                  <div className="bg-white/60 w-10 h-20 rounded-t-lg relative animate-pulse shadow-lg"></div>
                  <div className="bg-white/80 w-10 h-32 rounded-t-lg relative animate-pulse shadow-lg" style={{animationDelay: '0.1s'}}></div>
                  <div className="bg-white/70 w-10 h-28 rounded-t-lg relative animate-pulse shadow-lg" style={{animationDelay: '0.2s'}}></div>
                  <div className="bg-white/90 w-10 h-40 rounded-t-lg relative animate-pulse shadow-lg" style={{animationDelay: '0.3s'}}></div>
                  <div className="bg-white w-10 h-36 rounded-t-lg relative animate-pulse shadow-lg" style={{animationDelay: '0.4s'}}></div>
                  <div className="bg-white/85 w-10 h-44 rounded-t-lg relative animate-pulse shadow-lg" style={{animationDelay: '0.5s'}}></div>
                  <div className="bg-white/75 w-10 h-30 rounded-t-lg relative animate-pulse shadow-lg" style={{animationDelay: '0.6s'}}></div>
                </div>
                <div className="mt-4 flex justify-between text-sm text-gray-600">
                  <span>Dom</span>
                  <span>Seg</span>
                  <span>Ter</span>
                  <span>Qua</span>
                  <span>Qui</span>
                  <span>Sex</span>
                  <span>Sáb</span>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            {user.role !== "admin" && (
              <ActivityFeed activities={activities} loading={activitiesLoading} />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
