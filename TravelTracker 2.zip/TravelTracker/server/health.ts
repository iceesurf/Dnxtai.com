import type { Express, Request, Response } from "express";

export function registerHealthRoutes(app: Express) {
  // Health check endpoint para monitoramento
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || 'development',
      version: '1.0.0'
    });
  });

  // Status endpoint mais detalhado
  app.get('/api/status', (_req: Request, res: Response) => {
    res.json({
      service: 'DNXTAI Platform',
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      environment: process.env.NODE_ENV || 'development',
      version: '1.0.0',
      platform: process.platform,
      node_version: process.version
    });
  });
}