# Next.ai Platform - DNXTAI.com

## Como rodar no Replit (plano free)

1. Abra o terminal no Replit.

2. Instale as dependências do frontend e faça build:
```
cd frontend
npm install
npm run build
```

3. Instale as dependências do backend e rode o servidor:
```
cd ../backend
npm install
npm start
```

4. Acesse a URL do Replit para usar a aplicação.

---

## Usuário padrão para login

- Email: admin@dnxtai.com  
- Senha: senha123

---

## Como migrar para Railway ou Render

1. Crie um repositório no GitHub com essa estrutura.

2. Configure o Railway ou Render para puxar do GitHub.

3. Configure as variáveis de ambiente se necessário.

4. Apontar seu domínio dnxtai.com para o serviço.

---

## Configuração do domínio dnxtai.com

1. No Google Domains, entre na configuração de DNS.

2. Aponte o registro A ou CNAME para o IP/URL do serviço escolhido.

3. Use Cloudflare para gerenciar DNS e SSL grátis (recomendado).

---

## Estrutura do projeto

- backend/: código Node.js Express + SQLite
- frontend/: React + Vite + TailwindCSS (buildado para produção)
- replit.nix: ambiente Node.js 18 + SQLite
- README.md: instruções

---

## Próximos passos

- Implementar módulos CRM, Chatbot, Workflows, etc.  
- Melhorar UI/UX e segurança.

---

Qualquer dúvida, só chamar! 🚀
