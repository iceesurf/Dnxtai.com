import React, { useState } from 'react';

export default function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [token, setToken] = useState(null);
  const [error, setError] = useState(null);

  const login = async () => {
    setError(null);
    try {
      const res = await fetch('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (res.ok) {
        setToken(data.token);
      } else {
        setError(data.error);
      }
    } catch {
      setError('Erro na conexão');
    }
  };

  if (token) {
    return <div className="p-6 text-purple-700">Logado com sucesso! Token JWT:<br/><code>{token}</code></div>;
  }

  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-purple-100 p-6">
      <h1 className="text-3xl font-bold mb-6 text-purple-700">Login DNXTAI</h1>
      <input
        type="email"
        placeholder="Email"
        className="mb-4 p-2 border border-purple-400 rounded w-64"
        value={email}
        onChange={e => setEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="Senha"
        className="mb-4 p-2 border border-purple-400 rounded w-64"
        value={password}
        onChange={e => setPassword(e.target.value)}
      />
      <button
        className="bg-purple-700 text-white px-4 py-2 rounded hover:bg-purple-900"
        onClick={login}
      >
        Entrar
      </button>
      {error && <p className="mt-4 text-red-600">{error}</p>}
    </div>
  );
}
