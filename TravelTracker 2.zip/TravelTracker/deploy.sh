#!/bin/bash

# Script de Deploy Automático - DNXTAI Platform
# Uso: ./deploy.sh [vercel|railway|docker]

set -e

echo "🚀 DNXTAI - Deploy Automático"
echo "================================="

# Verificar se foi passado o tipo de deploy
if [ $# -eq 0 ]; then
    echo "❌ Erro: Especifique o tipo de deploy"
    echo "Uso: ./deploy.sh [vercel|railway|docker]"
    exit 1
fi

DEPLOY_TYPE=$1

echo "📦 Instalando dependências..."
npm ci

echo "🔧 Verificando tipos..."
npm run typecheck

echo "🏗️  Fazendo build da aplicação..."
npm run build

case $DEPLOY_TYPE in
    "vercel")
        echo "☁️  Fazendo deploy no Vercel..."
        npm run deploy:vercel
        ;;
    "railway")
        echo "🚂 Fazendo deploy no Railway..."
        npm run deploy:railway
        ;;
    "docker")
        echo "🐳 Construindo imagem Docker..."
        npm run docker:build
        echo "✅ Imagem Docker criada!"
        echo "Para executar: npm run docker:run"
        ;;
    *)
        echo "❌ Tipo de deploy inválido: $DEPLOY_TYPE"
        echo "Opções disponíveis: vercel, railway, docker"
        exit 1
        ;;
esac

echo ""
echo "✅ Deploy concluído com sucesso!"
echo ""
echo "📋 Próximos passos:"
echo "1. Configurar variáveis de ambiente (.env)"
echo "2. Testar a aplicação em produção"
echo "3. Configurar domínio personalizado (se necessário)"
echo ""
echo "🔗 URLs úteis:"
echo "- Health Check: /api/health"
echo "- Status: /api/status"
echo "- Login: /login"
echo ""
echo "📞 Contas de demonstração:"
echo "- Admin: admin@dnxtai.com / senha123"
echo "- Empresa: user@empresa.com / senha123"