import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import StatsGrid from "@/components/dashboard/stats-grid";
import CompaniesTable from "@/components/admin/companies-table";

export default function Admin() {
  const [, setLocation] = useLocation();
  const { user, isLoading } = useAuth();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    enabled: !!user && user.role === "admin",
  });

  const { data: companies, isLoading: companiesLoading } = useQuery({
    queryKey: ["/api/companies"],
    enabled: !!user && user.role === "admin",
  });

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "admin")) {
      setLocation("/login");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-2xl text-dnx-primary"></i>
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <Header />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <div className="mb-8 animate-slide-up">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">
                  Painel Administrativo DNXTAI
                </h1>
                <p className="text-gray-300 mt-2 text-lg">Gerenciamento centralizado de todas as empresas e recursos</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-xl border border-white/20">
                <span className="text-gray-300 text-sm">Admin Mode </span>
                <span className="text-white font-bold">Ativo</span>
              </div>
            </div>
          </div>

          <StatsGrid stats={stats} loading={statsLoading} isAdmin={true} />

          <div className="mt-8">
            <CompaniesTable companies={companies} loading={companiesLoading} />
          </div>
        </main>
      </div>
    </div>
  );
}
