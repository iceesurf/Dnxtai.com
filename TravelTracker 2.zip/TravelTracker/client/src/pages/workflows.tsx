import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Sidebar from "@/components/layout/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Workflows() {
  const [, setLocation] = useLocation();
  const { user, isLoading } = useAuth();

  const { data: workflows, isLoading: workflowsLoading } = useQuery({
    queryKey: ["/api/workflows"],
    enabled: !!user && user.role !== "admin",
  });

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/login");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <i className="fas fa-spinner fa-spin text-2xl text-dnx-primary"></i>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const mockWorkflows = [
    {
      id: 1,
      name: "Email de Boas-vindas",
      status: "active",
      description: "Envio automático de email para novos clientes",
      triggers: 3,
      executions: 127,
    },
    {
      id: 2,
      name: "Follow-up de Vendas",
      status: "draft",
      description: "Sequência de emails para leads qualificados",
      triggers: 2,
      executions: 45,
    },
    {
      id: 3,
      name: "Notificação WhatsApp",
      status: "active",
      description: "Mensagem automática via WhatsApp Business",
      triggers: 5,
      executions: 89,
    },
  ];

  const getStatusBadge = (status: string) => {
    return status === "active" ? "default" : "secondary";
  };

  const getStatusIcon = (status: string) => {
    return status === "active" ? "fas fa-play" : "fas fa-pause";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-purple-50/30 to-gray-100">
      <Header />
      
      <div className="flex">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <div className="mb-8 animate-slide-up">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-900 to-dnx-primary bg-clip-text text-transparent">
                  Workflows Inteligentes
                </h1>
                <p className="text-gray-600 mt-2 text-lg">
                  Automatize processos e fluxos de trabalho com IA
                </p>
              </div>
              <Button className="bg-dnx-gradient hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                <i className="fas fa-plus mr-2"></i>
                Novo Workflow
              </Button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockWorkflows.map((workflow, index) => (
              <Card key={workflow.id} className="hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 bg-white/80 backdrop-blur-sm border-purple-100 animate-scale-in" style={{animationDelay: `${index * 0.1}s`}}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg font-bold">{workflow.name}</CardTitle>
                    <Badge variant={getStatusBadge(workflow.status)} className="flex items-center">
                      <i className={`${getStatusIcon(workflow.status)} mr-1 text-xs`}></i>
                      {workflow.status === "active" ? "Ativo" : "Rascunho"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{workflow.description}</p>
                  
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="bg-blue-50 p-3 rounded-lg text-center">
                      <div className="text-2xl font-bold text-blue-600">{workflow.triggers}</div>
                      <div className="text-xs text-gray-600">Triggers</div>
                    </div>
                    <div className="bg-green-50 p-3 rounded-lg text-center">
                      <div className="text-2xl font-bold text-green-600">{workflow.executions}</div>
                      <div className="text-xs text-gray-600">Execuções</div>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" className="flex-1 hover:bg-purple-50">
                      <i className="fas fa-edit mr-1"></i>
                      Editar
                    </Button>
                    <Button variant="outline" size="sm" className="hover:bg-blue-50">
                      <i className="fas fa-chart-bar mr-1"></i>
                    </Button>
                    <Button variant="outline" size="sm" className="hover:bg-green-50">
                      <i className="fas fa-play mr-1"></i>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-8">
            <Card className="shadow-xl bg-white/80 backdrop-blur-sm border-purple-100">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-lightbulb text-yellow-500 mr-2"></i>
                  Templates Recomendados
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl border border-blue-100 hover:shadow-md transition-shadow cursor-pointer">
                    <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mb-3">
                      <i className="fas fa-envelope text-white"></i>
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">Email Marketing</h4>
                    <p className="text-sm text-gray-600">Campanhas automatizadas de email</p>
                  </div>
                  
                  <div className="p-4 bg-gradient-to-br from-green-50 to-blue-50 rounded-xl border border-green-100 hover:shadow-md transition-shadow cursor-pointer">
                    <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mb-3">
                      <i className="fab fa-whatsapp text-white"></i>
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">WhatsApp Bot</h4>
                    <p className="text-sm text-gray-600">Atendimento automatizado via WhatsApp</p>
                  </div>
                  
                  <div className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border border-purple-100 hover:shadow-md transition-shadow cursor-pointer">
                    <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mb-3">
                      <i className="fas fa-users text-white"></i>
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">Lead Nurturing</h4>
                    <p className="text-sm text-gray-600">Nutrição automática de leads</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}