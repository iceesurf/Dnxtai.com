import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CompaniesTableProps {
  companies: any[];
  loading: boolean;
}

export default function CompaniesTable({ companies, loading }: CompaniesTableProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      await apiRequest("POST", `/api/companies/${id}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/companies"] });
      toast({
        title: "Status atualizado",
        description: "O status da empresa foi atualizado com sucesso.",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao atualizar o status da empresa.",
        variant: "destructive",
      });
    },
  });

  const handleStatusChange = (id: number, currentStatus: string) => {
    const newStatus = currentStatus === "active" ? "suspended" : "active";
    updateStatusMutation.mutate({ id, status: newStatus });
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Empresas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <Skeleton className="w-12 h-12 rounded-lg" />
                <div className="space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getPlanBadge = (plan: string) => {
    const variants = {
      free: "secondary",
      pro: "default",
      enterprise: "destructive",
    };
    return variants[plan as keyof typeof variants] || "secondary";
  };

  const getStatusBadge = (status: string) => {
    return status === "active" ? "default" : "destructive";
  };

  return (
    <Card className="shadow-xl bg-white/80 backdrop-blur-sm border-purple-100 animate-scale-in">
      <CardHeader>
        <CardTitle className="flex items-center">
          <i className="fas fa-building text-dnx-primary mr-2"></i>
          Empresas Recentes
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Empresa</TableHead>
              <TableHead>Plano</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {companies && companies.length > 0 ? (
              companies.map((company) => (
                <TableRow key={company.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-dnx-gradient rounded-xl flex items-center justify-center shadow-lg">
                        <span className="text-white font-bold text-sm">
                          {company.name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900">{company.name}</div>
                        <div className="text-sm text-gray-600 flex items-center">
                          <i className="fas fa-envelope mr-1 text-xs"></i>
                          {company.email}
                        </div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={getPlanBadge(company.plan)}>
                      {company.plan.charAt(0).toUpperCase() + company.plan.slice(1)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={getStatusBadge(company.status)}>
                      {company.status === "active" ? "Ativo" : "Suspenso"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" className="hover:bg-purple-50 hover:border-purple-200">
                        <i className="fas fa-edit mr-1"></i>
                        Editar
                      </Button>
                      <Button
                        variant={company.status === "active" ? "destructive" : "default"}
                        size="sm"
                        onClick={() => handleStatusChange(company.id, company.status)}
                        disabled={updateStatusMutation.isPending}
                        className="transition-all duration-200"
                      >
                        <i className={`fas ${company.status === "active" ? "fa-pause" : "fa-play"} mr-1`}></i>
                        {company.status === "active" ? "Suspender" : "Ativar"}
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8">
                  <i className="fas fa-building text-gray-400 text-3xl mb-4"></i>
                  <p className="text-gray-500">Nenhuma empresa encontrada</p>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
